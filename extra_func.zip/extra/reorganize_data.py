# -*- coding: utf-8 -*-
"""
Created on Wed May 31 11:36:10 2023

@author: cvanb
"""

# Import libraries
import sys
import pandas as pd
import numpy as np
import os
import skimage.io as skio
from tensorflow.keras.models import Sequential
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from keras import regularizers, optimizers
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow.keras.layers import Conv2D,MaxPooling2D,Dense,Flatten,Dropout,Activation,BatchNormalization,Rescaling

######################### begin part to modify
cwd = os.getcwd() # automatically detect the current working directory
cwd = 'C:/Users/cvanb/Documents/3-MASTER SCIENCES COG/M1 DALETh/S2/Data_challenge'# manually
testfolder = '/test/' # the name of the datafolder 
trainfolder = '/train/' # the name of the folder in which to write output
######################### end part to modify

# Get the filenames into the train folder
testfiles = [i for i in os.listdir(cwd+testfolder) if i.split('.')[-1]=='csv']
trainfiles = [i for i in os.listdir(cwd+trainfolder) if i.split('.')[-1]=='csv']

# List the datasets
datasets = ['1', '2', '3']

# Rearrange the folders to it is easier after:
for ds in datasets:
    # Filter training folders
    # Dataset
    ds_folder = 'dataset_'+ds
    img_folder = cwd+trainfolder+ds_folder
    
    # Get the specific file for this part 1
    trainfile = [i for i in trainfiles if i.split('_')[1]==ds][0]
    
    # Read the csv files to dataframe
    traindf = pd.read_csv(cwd+trainfolder+trainfile, sep=',')
    
    # Filter the directory if first run
    for filename in os.listdir(img_folder+'/OK'):
        if filename not in list(traindf.name):
            os.remove(os.path.join(img_folder+'/OK', filename))
    
    for filename in os.listdir(img_folder+'/Vague'):
        if filename not in list(traindf.name):
            os.remove(os.path.join(img_folder+'/Vague', filename))
    
    # Filter test folders
    img_folder = cwd+testfolder+ds_folder

    # Get the specific file for this part 1
    testfile = [i for i in testfiles if i.split('_')[1]==ds][0]

    # Read the csv files to dataframe
    testdf = pd.read_csv(cwd+testfolder+testfile, sep=',')

    # Filter the directory if first run
    for filename in os.listdir(img_folder):
        if filename not in list(testdf.name):
            os.remove(os.path.join(img_folder, filename))
