# -*- coding: utf-8 -*-
"""
Created on Wed Jun  7 18:06:34 2023

@author: cvanb
"""
# Import libraries
import pandas as pd
import numpy as np
from keras.models import load_model
import os 
import skimage.io as skio

############### begin part to modify
modelpath = 'C:/Users/cvanb/Documents/3-MASTER SCIENCES COG\M1 DALETh/S2/Data_challenge/models/'
modelname = 'resnet50_v2.h5'
imgpath = 'C:/Users/cvanb/Documents/3-MASTER SCIENCES COG/M1 DALETh/S2/Data_challenge/test/dataset_1/'
testfolder = 'C:/Users/cvanb/Documents/3-MASTER SCIENCES COG/M1 DALETh/S2/Data_challenge/test/'
csvfile_name = 'dataset_1_test.csv'
outputfolder = 'C:/Users/cvanb/Documents/3-MASTER SCIENCES COG/M1 DALETh/S2/Data_challenge/predictions/'
################ end part to modify

# Load the trained model
model = load_model(modelpath+modelname)

# Get files variables
images=os.listdir(imgpath)
print('Number of stimuli:', len(images))

# Read the existing CSV file into a DataFrame
df = pd.read_csv(testfolder+csvfile_name)

# Map the prediction index to its corresponding label
label_mapping = {0: 'OK', 1: 'Vague'}  # Add more labels as needed

# For each image, make predictions and write it in the dataframe
for image in images:
    # Load the image
    img=skio.imread(imgpath+image) 
    
    # Expand dimensions to match the input shape expected by the model
    input_image = np.expand_dims(img, axis=0)
    
    # Do the prediction for that specific image
    prediction=model.predict(input_image)
    
    # Get the corresponding label
    label_index = np.argmax(prediction)
    predicted_label = label_mapping[label_index]
    
    # Write in corresponding row of df
    df.Label[df.name == image] = predicted_label

# Save the updated DataFrame as a CSV file
df.to_csv(outputfolder+csvfile_name, index=False)

print(f"Predictions updated and saved to {outputfolder+csvfile_name}.")
