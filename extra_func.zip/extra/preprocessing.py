# -*- coding: utf-8 -*-
"""
Preprocessing the images.
Created on Mon Jun  5 14:20:32 2023

@author: cvanb
"""
# Import libraries
from os.path import join
from os import listdir, getcwd
import skimage.io as skio
import skimage.exposure as ske
from skimage.util import img_as_ubyte, img_as_uint
from skimage import filters
from skimage import img_as_float
from skimage.color import rgb2gray
import numpy as np
import scipy.fftpack as sc
import matplotlib.pyplot as plt

############################ begin part to modify
cwd = getcwd() # automatically get current working directory
cwd = 'C:/Users/cvanb/Documents/3-MASTER SCIENCES COG/M1 DALETh/S2/Data_challenge/' # or manually

inputfolder = 'train/dataset_1/Vague/' # the folder where the images to be modified are
outputfolder = 'train/dataset_1/Vague_alt/' # the folder to put the new images
########################### end part to modify

# Get the full paths 
dirpath_in = cwd+inputfolder # input folder
dirpath_out = cwd+outputfolder # output folder

# Create the function 
def preprocess(method=str, cutoff=0.08, order=3.0):
    n = len(listdir(dirpath_in)) # number of images to preprocess
    print(f'Modifying {n} images with {method}, please wait. ', end='')
    for filename in listdir(dirpath_in): # for each image
        print('.', end='')
        # Set input and output paths
        inpath = join(dirpath_in, filename) 
        outpath = join(dirpath_out, filename)
        
        image=skio.imread(inpath) # read the image
        image=img_as_float(image) # to float 
        
        if method=='hist_stretch': # if histogram stretching
            image_m=ske.rescale_intensity(image)
            image_m=img_as_ubyte(image_m)
            
        elif method=='hist_eq': # if histogram equalization
            image_m=ske.equalize_hist(image)
            image_m=img_as_ubyte(image_m)
            
        elif method=='sobel': # if sobel edges filter
            image_m = filters.sobel(image)
            image_m=img_as_ubyte(image_m)
            
        elif method=='butter': # if butterworth filter
            image_m = filters.butterworth(
                image/255.,
                cutoff_frequency_ratio=cutoff, # float 
                order=order, # order of the filter
                high_pass=True) # if it should be highpass or not
            image_m=img_as_ubyte(image_m)
            
        elif method=='farid': # if farid filter
            image_m = filters.farid(image_m)
            image_m=img_as_ubyte(image_m)
            
        elif method=='fourier': # if fourier transform
            TFI=sc.fft2(image)
            TFI=sc.fftshift(TFI)
            image_m=np.log(np.abs(TFI**2))
            
        skio.imsave(outpath, image_m) # save the image
    print(f'\nDone, images saved to {dirpath_out}.')

# Run it (Note: Best one for humans eyes seems to be hist_eq)
preprocess('hist_eq')


